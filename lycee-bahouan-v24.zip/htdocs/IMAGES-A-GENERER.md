# Images à générer par IA (27) et photos à prendre (15)

Chaque image porte **exactement** le nom indiqué (`nom.jpg`) et remplace l'image repère du dossier `images/`.

**Consignes communes** : aucune écriture dans l'image (l'IA fait des fautes, et le texte est déjà dans la page) ; aucun logo ; aucun visage reconnaissable ; 
bannières 1920×600 : générez en format le plus large possible (ex. 21:9) puis recadrez ; gardez la partie gauche calme (le titre s'y affiche).

**Style à ajouter à chaque prompt** : `clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces`

---

## A. Images à générer par IA

### `cta-fond.jpg` — 1920 × 800
- **Où** : Accueil : fond du bloc final (Se renseigner, Visiter, S'inscrire)
- **Description** : Fond abstrait bleu nuit vers bleu roi, très doux, avec une silhouette lointaine de bâtiment scolaire et de palmiers. Grand espace vide au centre, assez sombre pour du texte blanc.
- **Prompt (anglais)** : abstract soft gradient background from midnight navy to royal blue, faint distant silhouette of a school building and palm trees, large empty centre, dark enough for white text, bokeh light particles, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-discipline.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Discipline
- **Description** : Bureau d'élève vu de dessus, très ordonné : cahier, règle, stylo alignés, sablier, lumière du petit matin.
- **Prompt (anglais)** : top-down view of a perfectly organised student desk, notebook, ruler and pen aligned, small hourglass, early morning light, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-assiduite.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Assiduité
- **Description** : Calendrier mural avec des jours cochés, réveil, rayon de soleil à travers une fenêtre de salle de classe.
- **Prompt (anglais)** : wall calendar with days ticked off in pen, small alarm clock on a desk, sunlight through a classroom window, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-respect.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Respect
- **Description** : Une poignée de main chaleureuse en gros plan, cour d'école floue en arrière-plan.
- **Prompt (anglais)** : close-up of two hands in a warm respectful handshake, blurred school courtyard with greenery behind, golden light, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-excellence.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Excellence
- **Description** : Trophée ou médaille dorée posé sur des livres, avec un mortier de diplômé, faible profondeur de champ.
- **Prompt (anglais)** : golden trophy and medal resting on a stack of books with a graduation cap, shallow depth of field, soft warm light, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-communaute.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Communauté
- **Description** : Des mains de peaux différentes empilées en cercle, vue de dessus, sans visages.
- **Prompt (anglais)** : overhead view of many hands of different skin tones stacked together in a circle, warm sunlight, no faces, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `valeur-culture.jpg` — 900 × 1100
- **Où** : Accueil / Valeurs : onglet Culture
- **Description** : Tissus africains wax colorés (motifs camerounais) et un tambour en bois, tons chauds.
- **Prompt (anglais)** : colourful African wax print fabrics with Cameroonian patterns and a carved wooden drum, warm tones, rich textures, vertical composition, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-admissions.jpg` — 1920 × 600
- **Où** : Page Admissions : bannière
- **Description** : Dossier d'inscription ouvert, stylo, carte d'élève vierge sur un bureau en bois, lumière de fenêtre.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, open registration folder with blank forms, pen and a blank student ID card on a wooden desk, soft window light, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-academique.jpg` — 1920 × 600
- **Où** : Page Académique : bannière
- **Description** : Pile de livres, cahier ouvert et instruments de géométrie, ambiance d'étude calme.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, stack of books, open notebook and geometry instruments on a desk, calm study mood, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-valeurs.jpg` — 1920 × 600
- **Où** : Page Valeurs : bannière
- **Description** : Escalier symbolique fait de livres qui monte vers une lumière dorée.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, symbolic staircase made of books rising toward golden sunrise light, inspiring mood, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-actualites.jpg` — 1920 × 600
- **Où** : Page Actualités : bannière
- **Description** : Panneau d'affichage avec feuilles et punaises, sans texte lisible.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, school bulletin board with pinned blank paper sheets and notices, no readable text, blue tones, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-contact.jpg` — 1920 × 600
- **Où** : Page Contact : bannière
- **Description** : Enveloppe, épingle de carte et smartphone posés sur un bureau, composition abstraite.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, envelope, map pin marker and smartphone on a clean desk, abstract communication theme, blue tones, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-anciens.jpg` — 1920 × 600
- **Où** : Page Anciens : bannière
- **Description** : Mortiers de diplômés lancés en l'air au coucher du soleil, vus de dos.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, graduation caps thrown in the air at golden hour, graduates seen from behind in silhouette, joyful, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-familles.jpg` — 1920 × 600
- **Où** : Page Espace familles : bannière
- **Description** : Silhouettes d'un parent et d'un enfant marchant vers une école au lever du soleil.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, silhouettes of a parent and child walking hand in hand toward a school building at sunrise, no faces, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-calendrier.jpg` — 1920 × 600
- **Où** : Page Calendrier : bannière
- **Description** : Agenda ouvert avec grille de calendrier vierge, horloge et crayon.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, open desk planner with blank calendar grid, small clock and pencil, tidy desk, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-equipe.jpg` — 1920 × 600
- **Où** : Page Équipe pédagogique : bannière
- **Description** : Table ronde vue de dessus avec carnets vierges et tasses, esprit d'équipe, sans visages.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, round meeting table seen from above with blank notebooks, pens and cups, teamwork mood, no people, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-galerie.jpg` — 1920 × 600
- **Où** : Page Galerie : bannière
- **Description** : Mur de cadres photo vides bleu et or, éclairage doux de galerie.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, gallery wall of empty blue and gold picture frames, soft gallery lighting, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-connexion.jpg` — 1920 × 600
- **Où** : Page Connexion : bannière
- **Description** : Smartphone et ordinateur portable avec écran de connexion lumineux sans texte, cadenas.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, smartphone and laptop with softly glowing blank login screens and a padlock symbol, secure access theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-resultats.jpg` — 1920 × 600
- **Où** : Page Résultats d'examens : bannière
- **Description** : Copie d'examen avec coches au stylo rouge et ruban de médaille, sans texte lisible.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, exam paper with red pen checkmarks and a medal ribbon, no readable text, achievement theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-club.jpg` — 1920 × 600
- **Où** : Page Club scientifique : bannière
- **Description** : Paillasse de laboratoire : microscope, fioles aux liquides bleus lumineux.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, school science lab bench with microscope and flasks of glowing blue liquids, clean bright laboratory, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-orientation.jpg` — 1920 × 600
- **Où** : Page Orientation : bannière
- **Description** : Boussole sur une carte, chemin sinueux vers l'horizon, panneau indicateur sans texte.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, compass on a map, winding path toward a bright horizon, blank signpost, guidance theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-emploi.jpg` — 1920 × 600
- **Où** : Page Emploi du temps : bannière
- **Description** : Grille d'horaires abstraite en blocs de couleurs sur tableau blanc, horloge.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, whiteboard with an abstract colourful timetable grid of blocks, wall clock, no readable text, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-reussite.jpg` — 1920 × 600
- **Où** : Page Réussite : bannière
- **Description** : Mortier de diplômé et diplôme roulé avec ruban doré, gros plan.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, close-up of graduation cap and rolled diploma with golden ribbon on a desk, success theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-faq.jpg` — 1920 × 600
- **Où** : Page FAQ : bannière
- **Description** : Bulles de dialogue et ampoule stylisées, fond bleu, sans texte.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, stylised speech bubbles and a light bulb on a blue background, questions and answers theme, no text, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-apropos.jpg` — 1920 × 600
- **Où** : Page À propos du site : bannière
- **Description** : Ordinateur portable avec maquette de page web vierge, lumières technologiques douces.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, laptop showing a blank website wireframe, soft tech glow, digital design theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `banniere-confidentialite.jpg` — 1920 × 600
- **Où** : Page Politique de confidentialité : bannière
- **Description** : Cadenas et bouclier sur fond numérique bleu abstrait.
- **Prompt (anglais)** : wide panoramic banner, subject placed on the right two thirds, calm soft left area kept uncluttered for a title, slightly muted contrast, padlock and shield over an abstract blue digital background, data protection theme, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

### `actualite-defaut.jpg` — 1200 × 800
- **Où** : Actualités : image utilisée quand une actualité n'a pas de photo
- **Description** : Visuel neutre : dégradé bleu avec une feuille de journal stylisée, sans texte.
- **Prompt (anglais)** : neutral blue gradient background with a simple stylised newspaper sheet illustration, minimal, no text, clean modern professional look, bright natural light, deep navy blue (#0B2A5B) and warm gold (#C9A13B) accents, high detail, sharp focus, NO text, NO letters, NO numbers, NO logos, NO watermark, no recognizable faces

---

## B. Photos réelles à prendre au lycée (ne pas générer)

### `hero-accueil.jpg` — 1920 × 1080
- **Où** : Accueil : grande image du haut (sert aussi d'aperçu quand le site est partagé)
- **À photographier** : Façade ou entrée principale du lycée, plan large, en plein jour (7 h–8 h ou fin d'après-midi), appareil à l'horizontale, sans voitures ni passants gênants, drapeau visible.

### `theme-terre.jpg` — 1600 × 900
- **Où** : Accueil : panneau « Bahouan, notre terre de savoir »
- **À photographier** : Vue large du campus et de sa végétation, ou du paysage de Bahouan (Bamendjou) autour du lycée.

### `theme-communaute.jpg` — 1600 × 900
- **Où** : Accueil : panneau « Une communauté bilingue »
- **À photographier** : Groupe d'élèves en uniforme dans la cour (accord des parents obligatoire), ou vu de dos.

### `video-poster.jpg` — 1600 × 900
- **Où** : Accueil : image affichée avant la lecture de la vidéo
- **À photographier** : Image extraite de votre vidéo de présentation, ou plan large de la cour.

### `banniere-lycee.jpg` — 1920 × 600
- **Où** : Page Le lycée : bannière
- **À photographier** : Le bâtiment principal en plan très large (format panoramique), côté gauche calme pour le titre.

### `banniere-vie-scolaire.jpg` — 1920 × 600
- **Où** : Page Vie scolaire : bannière
- **À photographier** : Élèves en activité dans la cour (jeu, sport), plan large, côté gauche dégagé.

### `banniere-visite.jpg` — 1920 × 600
- **Où** : Page Visite : bannière
- **À photographier** : Portail ou entrée d'accueil du lycée, plan large.

### `lycee-batiment.jpg` — 1200 × 800
- **Où** : Page Le lycée : photo du bâtiment / de la cour
- **À photographier** : Bâtiment et cour, plan moyen, bon éclairage.

### `lycee-chefferie.jpg` — 1200 × 800
- **Où** : Page Le lycée : photo liée à Bahouan et sa chefferie
- **À photographier** : Chefferie de Bahouan ou lieu emblématique du village (avec l'accord de la chefferie).

### `proviseur.jpg` — 600 × 750
- **Où** : Page Le lycée : portrait du proviseur
- **À photographier** : Portrait vertical (4:5), buste, fond neutre, tenue officielle, bonne lumière de face.

### `vie-sport.jpg` — 1200 × 800
- **Où** : Page Vie scolaire : sport et gymnase
- **À photographier** : Terrain ou gymnase avec une séance d'EPS.

### `vie-cantine.jpg` — 1200 × 800
- **Où** : Page Vie scolaire : cantine
- **À photographier** : Cantine ou espace repas, propre et en service.

### `vie-bibliotheque.jpg` — 1200 × 800
- **Où** : Page Vie scolaire : bibliothèque
- **À photographier** : Rayons et tables de la bibliothèque, élèves en lecture si possible.

### `vie-nkaing.jpg` — 1200 × 800
- **Où** : Page Vie scolaire : festival Nkaing
- **À photographier** : Un moment du festival Nkaing (danse, costumes, public).

### `admissions-secretariat.jpg` — 1200 × 800
- **Où** : Page Admissions : secrétariat / accueil
- **À photographier** : Bureau d'accueil du secrétariat, avec une personne de l'équipe si possible.

---

## C. Déjà en place

`logo.jpg`, `logo-blanc.png`, `icon-192.png`, `icon-512.png`.

## D. Retirées (jamais affichées par le site)

14 vignettes `matiere-*`, 8 `explore-*`, 4 `portrait-*`, `theme-numerique`, `galerie-defaut` : conservées dans `archives/anciennes-images-v23/`.
